layer = QgsProject.instance().mapLayer('[% @layer_id %]')
layer.selectByExpression('"type"=\'[%type%]\'')
