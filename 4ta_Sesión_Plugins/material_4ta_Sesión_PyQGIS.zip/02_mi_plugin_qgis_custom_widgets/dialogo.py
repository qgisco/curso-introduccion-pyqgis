import os

from qgis.PyQt.QtWidgets import QDialog
from qgis.PyQt.uic import loadUi
from qgis.core import QgsMapLayer

class MiDialogo(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        loadUi(os.path.join(os.path.dirname(__file__), "dialogo.ui"), self)


