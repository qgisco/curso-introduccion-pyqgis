from .mi_plugin_custom_widgets import MiPlugin2

def classFactory(iface):
    return MiPlugin2(iface)

