import os

from qgis.PyQt.QtWidgets import QDialog
from qgis.PyQt.uic import loadUi


class MiDialogo(QDialog):
    def __init__(self, iface):
        QDialog.__init__(self)
        self.iface = iface
        loadUi(os.path.join(os.path.dirname(__file__), "dialogo.ui"), self)
